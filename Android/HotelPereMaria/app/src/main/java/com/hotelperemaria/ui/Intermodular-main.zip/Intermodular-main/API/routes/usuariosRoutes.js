const express = require('express');
const router = express.Router();
const Usuario = require('../models/usuarios');
const { authenticate } = require('../middleware/auth.js');

router.use(authenticate);

router.get('/', async (req, res) => {
    try {
        const { nombre, apellido, email, NIF, username, tipo } = req.query;
        let query = { desactivado: false };

        if (nombre) query['nombre'] = { $regex: new RegExp(nombre, 'i') };
        if (apellido) query['apellido'] = { $regex: new RegExp(apellido, 'i') };
        if (email) query['email'] = { $regex: new RegExp(email, 'i') };
        if (NIF) query['NIF'] = { $regex: new RegExp(NIF, 'i') };
        if (username) query['username'] = { $regex: new RegExp(username, 'i') };
        if (tipo) query['tipo'] = parseInt(tipo);

        const usuarios = await Usuario.find(query).populate('id_avatar');
        res.status(200).json(usuarios);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error al obtener usuarios" });
    }
});


router.get('/:id', async (req, res) => {
    try {
        const usuario = await Usuario.findById(req.params.id).populate('id_avatar');
        if (!usuario || usuario.desactivado) {
            return res.status(404).json({ error: 'Usuario no encontrado o desactivado' });
        }
        res.status(200).json(usuario);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error al obtener el usuario" });
    }
});

router.post('/', async (req, res) => {
    try {
        const { nombre, apellido, email, username, password, tipo } = req.body;

        // 🔍 **Validaciones manuales**
        if (!nombre || nombre.trim().length < 1) {
            return res.status(400).json({ error: 'El nombre debe tener al menos 1 caracteres.' });
        }
        if (!apellido || apellido.trim().length < 1) {
            return res.status(400).json({ error: 'El apellido debe tener al menos 1 caracteres.' });
        }
        if (!email || !email.includes('@')) {
            return res.status(400).json({ error: 'Debe proporcionar un email válido.' });
        }
        if (!username || username.trim().length < 1) {
            return res.status(400).json({ error: 'El username debe tener al menos 1 caracteres.' });
        }
        if (!password || password.length < 3) {
            return res.status(400).json({ error: 'La contraseña debe tener al menos 3 caracteres.' });
        }
        if (![1, 2, 3, 5].includes(tipo)) {
            return res.status(400).json({ error: 'El tipo de usuario es inválido.' });
        }


        const usuario = new Usuario(req.body);
        await usuario.save();

        res.status(201).json(usuario);
    } catch (error) {
        console.error(error);
        res.status(400).json({ error: error.message });
    }
});


module.exports = router;
