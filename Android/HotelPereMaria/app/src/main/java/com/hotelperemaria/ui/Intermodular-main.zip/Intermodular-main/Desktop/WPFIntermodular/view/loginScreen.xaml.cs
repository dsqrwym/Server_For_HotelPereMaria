﻿using GalaSoft.MvvmLight.Command;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFIntermodular.view

{
    /// <summary>
    /// Interaction logic for loginScreen.xaml
    /// </summary>
    public partial class loginScreen : Window
    {
        private NavigationService _navigationService;
        private readonly HttpClient _httpClient = new HttpClient();

        public RelayCommand NavigateToSecondWindowCommand { get; private set; }

        public loginScreen()
        {
            InitializeComponent();
            _navigationService = new NavigationService();  // Crear una instancia del servicio
            NavigateToSecondWindowCommand = new RelayCommand(nav);
        }

       

        private async void loginBtn_Click(object sender, RoutedEventArgs e)
        {
            string email = loginUsername.Text;
            string password = loginPassword.Text;

            try
            {
                var userData = new { email, password };
                string json = JsonConvert.SerializeObject(userData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await _httpClient.PostAsync("http://localhost:3000/api/auth/login", content);
                string result = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var responseData = JsonConvert.DeserializeObject<dynamic>(result);

                    string accessToken = responseData.accessToken;
                    string refreshToken = responseData.refreshToken;

                    MessageBox.Show("Inicio de sesión exitoso " + accessToken, "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);
                    ConexionApi.token = accessToken;
                    nav();
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                 Console.WriteLine($"Error: {ex.Message}");
            }
        }
        private void nav()
        {
            this.Hide();
            _navigationService.NavigateTo("buscarReserva");
           
        }
    }
}
