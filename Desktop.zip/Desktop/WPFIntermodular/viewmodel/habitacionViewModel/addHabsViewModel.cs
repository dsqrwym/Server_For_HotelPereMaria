﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using GalaSoft.MvvmLight.Command;
using WPFIntermodular.model;
using System.Windows.Controls;

namespace WPFIntermodular.viewmodel.habitacionViewModel
{
    public class addHabsViewModel : INotifyPropertyChanged
        {
        private readonly string[] tiposHabitacion = { "Individual", "Estandar", "Lujo", "Suite", "Duplex" };
        public string[] TiposHabitacion => tiposHabitacion;


        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private byte[] _imageBytes;
        private bool _editar;
        private Habitacion _habitacion;
        private readonly NavigationService _navigationService;

        public bool Editar
        {
            get => _editar;
            set => SetProperty(ref _editar, value);

        }

        public Habitacion Habitacion
        {
            get => _habitacion;
            set => SetProperty(ref _habitacion, value);
        }

        private string _nombre;
        public string Nombre
        {
            get => _nombre;
            set => SetProperty(ref _nombre, value);
        }

        private string _tipo;
        public string Tipo
        {
            get => _tipo;
            set => SetProperty(ref _tipo, value);
        }

        private int _index;
        public int index
        {
            get => _index;
            set => SetProperty(ref _index, value);

        }

        private int _selectedTipoIndex;
        public int SelectedTipoIndex
        {
            get => _selectedTipoIndex;
            set
            {
                if (_selectedTipoIndex != value)
                {
                    _selectedTipoIndex = value;
                    OnPropertyChanged(nameof(SelectedTipoIndex));

                    if (_selectedTipoIndex >= 0 && _selectedTipoIndex < tiposHabitacion.Length)
                        Tipo = tiposHabitacion[_selectedTipoIndex];
                    else
                        Tipo = "";
                }
            }
        }
        private string _descripcion;
        public string Descripcion
        {
            get => _descripcion;
            set => SetProperty(ref _descripcion, value);
        }

        private BitmapImage _imagenPreview;

        public event PropertyChangedEventHandler? PropertyChanged;

        public BitmapImage ImagenPreview
        {
            get => _imagenPreview;
            set => SetProperty(ref _imagenPreview, value);
        }
        

        public ICommand SeleccionarImagenCommand { get; }
        public ICommand GuardarHabitacionCommand { get; }
        public ICommand CerrarCommand { get; }

        public addHabsViewModel(Habitacion habitacion, bool editar)
        {
            _navigationService = new NavigationService();
            Habitacion = habitacion;
            Editar = editar;

            if(editar)
            {
                Nombre = Habitacion.Nombre;
                Tipo = Habitacion.Tipo;
                Descripcion = Habitacion.Descripccion;
            }
            SelectedTipoIndex = Array.IndexOf(tiposHabitacion, habitacion.Tipo);


            SeleccionarImagenCommand = new RelayCommand(SeleccionarImagen);
            CerrarCommand = new RelayCommand(CerrarVentana);
        }

        private static addHabsViewModel _instancia;
       

        private void SeleccionarImagen()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Seleccionar archivo de imagen",
                Filter = "Imágenes|*.jpg;*.png;*.gif",
                Multiselect = false
            };

            if (openFileDialog.ShowDialog() == true)
            {
                _imageBytes = File.ReadAllBytes(openFileDialog.FileName);
                ImagenPreview = ConvertirBytesAImagen(_imageBytes);
            }
        }

        private BitmapImage ConvertirBytesAImagen(byte[] imagenBytes)
        {
            if (imagenBytes == null || imagenBytes.Length == 0)
                return null;

            using (var stream = new MemoryStream(imagenBytes))
            {
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.StreamSource = stream;
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                return bitmap;
            }
        }

        public bool GuardarHabitacion()
        {
            Habitacion.Nombre = Nombre;
            Habitacion.Tipo = Tipo;
            Habitacion.Descripccion = Descripcion;
            bool correcto =comps();

            if (!correcto)
            {
                MessageBox.Show("Completa todos los campos");
                return false;
            }
            else
            {
                if (Editar)
                {
                    MessageBox.Show("Habitación editada correctamente.");
                    _navigationService.NavigateTo("buscarHab");
                    return true;

                }
                else
                {
                    MessageBox.Show("Nueva habitación creada.");
                    _navigationService.NavigateTo("buscarHab");
                    return true;

                }
            }
            

        }

        private void CerrarVentana()
        {
            
            _navigationService.NavigateTo("buscarHab");
        }
        private bool comps()
        {
            if(string.IsNullOrEmpty(Nombre)) return false;
            if(string.IsNullOrEmpty(Tipo)) return false;
            if(string.IsNullOrEmpty(Descripcion)) return false;
            if (_imageBytes == null || _imageBytes.Length == 0) return false; 



            return true;
        }






        private void SetProperty<T>(ref T field, T value, [System.Runtime.CompilerServices.CallerMemberName] string propertyName = null)
        {
            if (!Equals(field, value))
            {
                field = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public bool CrearEditar()
        {
            GuardarHabitacion();
            return comps();
        }
    }
}
